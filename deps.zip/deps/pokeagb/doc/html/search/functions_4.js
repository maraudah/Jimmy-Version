var searchData=
[
  ['exec_5fbattle',['exec_battle',['../map_8h.html#a14363bdd9810d375d7b22b4261b95f47',1,'map.h']]],
  ['exit_5fto_5foverworld_5f2_5fswitch',['exit_to_overworld_2_switch',['../loading_8h.html#a9501e83a3004f5a3e8acf64f4b121954',1,'loading.h']]]
];
