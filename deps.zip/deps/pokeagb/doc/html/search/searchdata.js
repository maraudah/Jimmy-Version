var indexSectionsWithContent =
{
  0: "abcdefghiklmnopqrstuvw",
  1: "abcdefilmnopqrstvw",
  2: "abcdefilmnoprstuv",
  3: "abcdefghilmnoprstvw",
  4: "abcdefghikmnoprstuvw",
  5: "os",
  6: "eikmpst",
  7: "eikmprst",
  8: "bdnvw",
  9: "ap"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines",
  9: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Macros",
  9: "Pages"
};

