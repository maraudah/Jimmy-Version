var searchData=
[
  ['taskcallback',['TaskCallback',['../task_8h.html#a80f4bf6fa02bd353f73de02fa603ae0c',1,'task.h']]],
  ['tasks',['tasks',['../task_8h.html#a4fd215833c913b684390b917193f8897',1,'task.h']]],
  ['tiles',['tiles',['../structMapBlockset.html#a227f8c5a3062e1fb19fd51d4c85259b8',1,'MapBlockset']]],
  ['tiles_5ftag',['tiles_tag',['../structScrollArrows.html#addb313817860821fd5c255c0bf066eff',1,'ScrollArrows']]],
  ['trainer_5fclass_5fmoney_5frate',['trainer_class_money_rate',['../trainer_8h.html#a8cdb6389e06ae45cb95797c7dededc99',1,'trainer.h']]],
  ['trainer_5fclass_5fnames',['trainer_class_names',['../trainer_8h.html#a76ad09560bf66e8777226eea0feeab49',1,'trainer.h']]],
  ['trainer_5fdata',['trainer_data',['../trainer_8h.html#a14ec7e16805f60952771b399aa072c9f',1,'trainer.h']]],
  ['trainerbattle_5fflag_5fid',['trainerbattle_flag_id',['../trainer_8h.html#a7c966a57a7055b4e0b07320db72997c7',1,'trainer.h']]],
  ['type',['type',['../structSignpostData.html#a0275c86fb6a42ccac30fd67edc1d2f60',1,'SignpostData::type()'],['../structEvolutionEntry.html#a129d47abeef343977512c078b6b48a21',1,'EvolutionEntry::type()']]]
];
