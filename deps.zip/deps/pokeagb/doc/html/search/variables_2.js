var searchData=
[
  ['character',['character',['../structTile.html#ac9172fa47b8a4be2fcd1d26bdc10075b',1,'Tile']]],
  ['checksum',['checksum',['../structPokemonBase.html#a5dd8b4219fc00de966fbbdc8370e8011',1,'PokemonBase']]],
  ['cmd_5ftable',['cmd_table',['../structScriptEnvironment.html#aa0dbdeb1ecd0a6a5f31693195f561562',1,'ScriptEnvironment']]],
  ['cmd_5ftable_5fmax',['cmd_table_max',['../structScriptEnvironment.html#a6648c3d57be1e493dccd1d9b1dc483da',1,'ScriptEnvironment']]],
  ['cmp_5fresult',['cmp_result',['../structScriptEnvironment.html#a8d63b184dedbb3b2788c84d17fc38856',1,'ScriptEnvironment']]],
  ['compressed',['compressed',['../structMapBlockset.html#af55575ff1bf2c8d989d869299ac162ca',1,'MapBlockset']]],
  ['contact',['contact',['../structMoveDataFlags.html#aa88b5df0807e15f2ddb872a078efe500',1,'MoveDataFlags']]],
  ['coordinates',['coordinates',['../structWarpData.html#aa6c7ffb5e9a36204cdc000962b48cd05',1,'WarpData::coordinates()'],['../structTriggerData.html#a8b671eb7a7d57d3211057e76d3cff565',1,'TriggerData::coordinates()'],['../structSignpostData.html#a6e89c0208efec1741b53a2879a269e81',1,'SignpostData::coordinates()']]],
  ['current_5fmap_5fheader',['current_map_header',['../virtual__map_8h.html#a37ed443f9f60dfc824e719befb4909e3',1,'virtual_map.h']]],
  ['currentmap_5fheader',['currentmap_header',['../map_8h.html#afff8e39ebb126d4b580708747ac882c9',1,'map.h']]]
];
