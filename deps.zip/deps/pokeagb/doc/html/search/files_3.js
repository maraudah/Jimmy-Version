var searchData=
[
  ['data_2eh',['data.h',['../battle_2data_8h.html',1,'']]],
  ['data_2eh',['data.h',['../pokemon_2data_8h.html',1,'']]]
];
