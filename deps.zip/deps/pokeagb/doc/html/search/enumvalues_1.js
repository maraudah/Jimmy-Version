var searchData=
[
  ['item_5ftype_5fgeneric_5fbattle',['ITEM_TYPE_GENERIC_BATTLE',['../item_8h.html#a34110e0949d97b4bb1cf4f3a7bed2c5da2b1f31c6aa378d4c999c7f1e3f61b7a3',1,'item.h']]],
  ['item_5ftype_5fgeneric_5fmail',['ITEM_TYPE_GENERIC_MAIL',['../item_8h.html#a34110e0949d97b4bb1cf4f3a7bed2c5dae1f70aa7ec68e74f540218f03eb6470c',1,'item.h']]],
  ['item_5ftype_5fgeneric_5foverworld',['ITEM_TYPE_GENERIC_OVERWORLD',['../item_8h.html#a34110e0949d97b4bb1cf4f3a7bed2c5da763a6bbbcbb2c8e78e6744042ec27838',1,'item.h']]],
  ['item_5ftype_5fgeneric_5fpokeblock_5fcase',['ITEM_TYPE_GENERIC_POKEBLOCK_CASE',['../item_8h.html#a34110e0949d97b4bb1cf4f3a7bed2c5daffdd5efaac0f2526b3199902c9f7d483',1,'item.h']]],
  ['item_5ftype_5fgeneric_5fregister',['ITEM_TYPE_GENERIC_REGISTER',['../item_8h.html#a34110e0949d97b4bb1cf4f3a7bed2c5dafdf72e586a90dbeac24e4c493eb01173',1,'item.h']]]
];
