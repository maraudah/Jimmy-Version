var searchData=
[
  ['battlepokemon',['BattlePokemon',['../structBattlePokemon.html',1,'']]],
  ['battlestuff',['BattleStuff',['../structBattleStuff.html',1,'']]],
  ['bgconfig',['BgConfig',['../structBgConfig.html',1,'']]],
  ['bgconfig2',['BgConfig2',['../structBgConfig2.html',1,'']]]
];
