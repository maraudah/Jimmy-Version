var searchData=
[
  ['ability_2eh',['ability.h',['../ability_8h.html',1,'']]],
  ['ability_5fsomething',['ability_something',['../command_8h.html#a79a8cb6457599b4917f779cd936931f7',1,'command.h']]],
  ['absent_5fflags_5ffor_5fbanks',['absent_flags_for_banks',['../battle_2data_8h.html#a0ab95cef51f10d1ba6a360c1fab01448',1,'data.h']]],
  ['add_5ftask_5ftrainer_5fwalk',['add_task_trainer_walk',['../trainer_8h.html#abeed61c3509bd1b4508606b29c4419b7',1,'trainer.h']]],
  ['address_20list_20_28bpre_29',['Address List (BPRE)',['../addressBPRE.html',1,'']]],
  ['affine_5fmode',['affine_mode',['../structOamData.html#a366e909e138456d46a5203b75f06adca',1,'OamData']]],
  ['affine_5freset_5fall',['affine_reset_all',['../graphics_2sprites_8h.html#ab592cb690f15ab6f78d9cea36a1f1300',1,'sprites.h']]],
  ['amount',['amount',['../structSignpostData.html#a4b688f1e705fc166a91bffbd819b9363',1,'SignpostData']]],
  ['an_5fexclamation_5fmark',['an_exclamation_mark',['../npc_8h.html#a8b24c3c1a488d138d3102032accca249',1,'npc.h']]],
  ['anim_5fimage_5fempty',['anim_image_empty',['../graphics_2sprites_8h.html#aee96e9163aeba29af94d71c40b150e11',1,'sprites.h']]],
  ['argument',['argument',['../structEvolutionEntry.html#a0cca4d1193dcee39d2d8bb7d40fd5b15',1,'EvolutionEntry']]],
  ['arrow',['Arrow',['../structScrollArrows_1_1Arrow.html',1,'ScrollArrows']]],
  ['audio_2eh',['audio.h',['../audio_8h.html',1,'']]],
  ['audio_5fplay',['audio_play',['../audio_8h.html#a8bdaf89d96c4a477e02fda174b9aaefd',1,'audio.h']]]
];
