var searchData=
[
  ['magic_5fcoat',['magic_coat',['../structMoveDataFlags.html#a79939e0c2155dbe01fee9d889cdadc1e',1,'MoveDataFlags']]],
  ['map',['map',['../structWarpData.html#ae54fa1d85189d968040b32e927b0e006',1,'WarpData']]],
  ['map_5fpost_5fload_5fhook',['map_post_load_hook',['../loading_8h.html#adccf13e828b72c9fe9d41f7b58d62484',1,'loading.h']]],
  ['markings',['markings',['../structPokemonBase.html#a72ca21fafc5c0bd9684baab16c3ad8cf',1,'PokemonBase']]],
  ['mirror_5fmove',['mirror_move',['../structMoveDataFlags.html#aed8b7f03efbb5920cefc5b41d89381d2',1,'MoveDataFlags']]],
  ['mode',['mode',['../structScriptEnvironment.html#a9992b51bc39c3dbd73400b824a8547d0',1,'ScriptEnvironment']]],
  ['mosaic',['mosaic',['../structOamData.html#aa07778360184dbaf34985a9b85e15f56',1,'OamData']]],
  ['move_5findex_5fchosen_5fper_5fside',['move_index_chosen_per_side',['../menu_8h.html#a5fb39f5f9549cd23b53596bb49f3eb9f',1,'menu.h']]],
  ['mplay_5fbgm',['mplay_BGM',['../m4a_8h.html#ac7260aaef47a12da33681a37034d81f3',1,'m4a.h']]],
  ['mplay_5fse1',['mplay_SE1',['../m4a_8h.html#ab5a0dd7981656fd27f5827b9413dd44c',1,'m4a.h']]],
  ['mplay_5fse2',['mplay_SE2',['../m4a_8h.html#a03989d3bca81eaf59af20b2fcf39cfb8',1,'m4a.h']]],
  ['mplay_5fse3',['mplay_SE3',['../m4a_8h.html#a71a064b5d329e94cde5eef661a1f8288',1,'m4a.h']]],
  ['mplaymemaccarea',['mplayMemAccArea',['../m4a_8h.html#a0f61e971155b749fbaf29430c298bfea',1,'m4a.h']]],
  ['mplaytable',['mplayTable',['../m4a_8h.html#ab77fff462dc480dfc80e8cf41bc3faa2',1,'m4a.h']]]
];
