var searchData=
[
  ['cgbchannel',['CgbChannel',['../structCgbChannel.html',1,'']]],
  ['color',['Color',['../unionColor.html',1,'']]],
  ['colorcomponents',['ColorComponents',['../structColorComponents.html',1,'']]],
  ['coords16',['Coords16',['../structCoords16.html',1,'']]],
  ['coords32',['Coords32',['../structCoords32.html',1,'']]],
  ['coords8',['Coords8',['../structCoords8.html',1,'']]]
];
