var searchData=
[
  ['lcd_5fio_5fget',['lcd_io_get',['../io_8h.html#ad133cf5409cdbcdad6e0b81750cc8a6c',1,'io.h']]],
  ['lcd_5fio_5fset',['lcd_io_set',['../io_8h.html#afd3190e925ea35d392e4a9589afff706',1,'io.h']]],
  ['learnsetentry',['LearnsetEntry',['../structLearnsetEntry.html',1,'']]],
  ['level_5fby_5fexp',['level_by_exp',['../pokemon_2data_8h.html#ace13f471fd68cd190567e0c774fe6c2d',1,'data.h']]],
  ['load_5fgfxc_5fhealth_5fbar',['load_gfxc_health_bar',['../ui_8h.html#a229c60e0875390366844528a51c06451',1,'ui.h']]],
  ['load_5fparty_5ficon_5fpalette_5findex',['load_party_icon_palette_index',['../pokeicons_8h.html#aff64fcc371660c0654fde4257ad07b10',1,'pokeicons.h']]],
  ['load_5fparty_5ficon_5ftiles_5fwith_5fform',['load_party_icon_tiles_with_form',['../pokeicons_8h.html#a5e2e6f4a1c99787a40de2e21bd1efd81',1,'pokeicons.h']]],
  ['loading_2eh',['loading.h',['../loading_8h.html',1,'']]],
  ['log_5fcoords_5frelative_5fcamera',['log_coords_relative_camera',['../map_8h.html#af301829a92e38b4219b5dd42931b0e61',1,'map.h']]],
  ['lz77uncompvram',['lz77UnCompVram',['../bios_8h.html#a66f50e3ca4e56a91100c3d6729c0a60a',1,'bios.h']]],
  ['lz77uncompwram',['LZ77UnCompWram',['../compression_8h.html#aae4dc906fe0a10fc4c4ebcaffede43cb',1,'compression.h']]]
];
