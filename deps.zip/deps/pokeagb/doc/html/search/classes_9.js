var searchData=
[
  ['npcstate',['NpcState',['../structNpcState.html',1,'']]]
];
