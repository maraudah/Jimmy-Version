var searchData=
[
  ['virtual_5fmap_5fborder_5fsize',['VIRTUAL_MAP_BORDER_SIZE',['../virtual__map_8h.html#a43fde6407a8126dc99943f8d03146ddf',1,'virtual_map.h']]],
  ['virtual_5fmap_5fhorizontal_5fpadding',['VIRTUAL_MAP_HORIZONTAL_PADDING',['../virtual__map_8h.html#ad06fa84896f59b3107d92b1292c4a741',1,'virtual_map.h']]],
  ['virtual_5fmap_5fmax_5fblocks',['VIRTUAL_MAP_MAX_BLOCKS',['../virtual__map_8h.html#a4c4fd0bb2ccb20802c7ef3b679f1f2ed',1,'virtual_map.h']]],
  ['virtual_5fmap_5fvertical_5fpadding',['VIRTUAL_MAP_VERTICAL_PADDING',['../virtual__map_8h.html#ad35b0a8cb1a9830d630320dfc106b770',1,'virtual_map.h']]]
];
