var searchData=
[
  ['game_5flanguage',['game_language',['../base_8h.html#a79a85fb10bdcb358eff7fc6fbe20e6a4',1,'base.h']]],
  ['gfx_5fheldicons',['gfx_heldicons',['../pokeicons_8h.html#a90e892e9e60207f107613af95d632e0b',1,'pokeicons.h']]],
  ['gpu_5fpal_5ftag_5fsearch_5flower_5fboundary',['gpu_pal_tag_search_lower_boundary',['../palette_8h.html#a1232570edd61f2780d29bfd78bf2d79c',1,'palette.h']]]
];
