var searchData=
[
  ['pokemondatarequest',['PokemonDataRequest',['../pokemon_2data_8h.html#a3f86d2f9e94db6f9c8adf80f28b7aa14',1,'data.h']]],
  ['pokemonlanguage',['PokemonLanguage',['../pokemon_2data_8h.html#ac830adec4dc112ed7f6590443a45489d',1,'data.h']]],
  ['pokemontype',['PokemonType',['../type_8h.html#a943d0c9094609e38e49057ca52d26c41',1,'type.h']]]
];
