var searchData=
[
  ['walkrun',['Walkrun',['../structWalkrun.html',1,'']]],
  ['walkrun_5fstate',['walkrun_state',['../npc_8h.html#a137175d6c6ce0f8363365ff64d6c6864',1,'npc.h']]],
  ['warpdata',['WarpData',['../structWarpData.html',1,'']]],
  ['wavedata',['WaveData',['../structWaveData.html',1,'']]],
  ['wild_5fpokemon',['wild_pokemon',['../structwild__pokemon.html',1,'']]],
  ['wild_5fpokemon_5fdata',['wild_pokemon_data',['../map_8h.html#af1e2ce561aefb9970181d354227edc7f',1,'map.h']]],
  ['wild_5fpokemon_5fdensities',['wild_pokemon_densities',['../unionwild__pokemon__densities.html',1,'']]],
  ['winin_5fbuild',['WININ_BUILD',['../io_8h.html#a6eb016699eb9cee2afd185d2e3ae62a7',1,'io.h']]],
  ['winout_5fbuild',['WINOUT_BUILD',['../io_8h.html#acc272be070afd8a167bf362433f6303c',1,'io.h']]],
  ['write_5fto_5frbox',['write_to_rbox',['../string_8h.html#a392d3ea1de3a2cebde21eb084d673047',1,'string.h']]]
];
