var searchData=
[
  ['fcode_5fbuffer2',['fcode_buffer2',['../string_8h.html#afb39d5074cbe20eea48f888a7ba872b6',1,'string.h']]],
  ['fcode_5fbuffer3',['fcode_buffer3',['../string_8h.html#ac44c45211b72994132f62e25edd08bfe',1,'string.h']]],
  ['fcode_5fbuffer4',['fcode_buffer4',['../string_8h.html#a604975981607c8d60434e78205a67f94',1,'string.h']]],
  ['field1',['field1',['../structMapBlockBehavior.html#ae90d24031522f647a3bcbef927d829f5',1,'MapBlockBehavior']]],
  ['flag',['flag',['../structSignpostData.html#a1805d2cf32de4845243a021161217585',1,'SignpostData']]],
  ['font',['font',['../structPokemonBase.html#a359f07bcedbd710e0eea6dbc7e1717fa',1,'PokemonBase']]],
  ['function',['function',['../structTask.html#a82536a29d961b597eef9a555277f751f',1,'Task::function()'],['../structMapBlockset.html#ad3d7b515a7ed5b50a3b7a9379940ffdf',1,'MapBlockset::function()']]]
];
