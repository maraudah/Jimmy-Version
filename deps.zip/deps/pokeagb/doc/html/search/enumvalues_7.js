var searchData=
[
  ['type_5fnone',['TYPE_NONE',['../type_8h.html#a943d0c9094609e38e49057ca52d26c41a01a66f4d8d66e4614c1c900c5a1c37ff',1,'type.h']]]
];
