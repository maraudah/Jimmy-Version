var searchData=
[
  ['walkrun',['Walkrun',['../structWalkrun.html',1,'']]],
  ['warpdata',['WarpData',['../structWarpData.html',1,'']]],
  ['wavedata',['WaveData',['../structWaveData.html',1,'']]],
  ['wild_5fpokemon',['wild_pokemon',['../structwild__pokemon.html',1,'']]],
  ['wild_5fpokemon_5fdensities',['wild_pokemon_densities',['../unionwild__pokemon__densities.html',1,'']]]
];
