var searchData=
[
  ['saveblock1',['SaveBlock1',['../structSaveBlock1.html',1,'']]],
  ['saveblock2',['SaveBlock2',['../structSaveBlock2.html',1,'']]],
  ['saveblock3',['SaveBlock3',['../structSaveBlock3.html',1,'']]],
  ['scriptenvironment',['ScriptEnvironment',['../structScriptEnvironment.html',1,'']]],
  ['scrollarrows',['ScrollArrows',['../structScrollArrows.html',1,'']]],
  ['scrollarrowtaskstate',['ScrollArrowTaskState',['../structScrollArrowTaskState.html',1,'']]],
  ['signpostdata',['SignpostData',['../structSignpostData.html',1,'']]],
  ['song',['Song',['../structSong.html',1,'']]],
  ['songheader',['SongHeader',['../structSongHeader.html',1,'']]],
  ['soundchannel',['SoundChannel',['../structSoundChannel.html',1,'']]],
  ['soundinfo',['SoundInfo',['../structSoundInfo.html',1,'']]],
  ['spritepalette',['SpritePalette',['../structSpritePalette.html',1,'']]],
  ['spritetiles',['SpriteTiles',['../structSpriteTiles.html',1,'']]],
  ['superstate',['Superstate',['../structSuperstate.html',1,'']]]
];
