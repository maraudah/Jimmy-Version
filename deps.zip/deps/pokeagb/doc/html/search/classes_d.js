var searchData=
[
  ['reg_5fbgcnt',['REG_BGCNT',['../structREG__BGCNT.html',1,'']]],
  ['romnpc',['RomNpc',['../structRomNpc.html',1,'']]],
  ['rotscaleframe',['RotscaleFrame',['../structRotscaleFrame.html',1,'']]]
];
