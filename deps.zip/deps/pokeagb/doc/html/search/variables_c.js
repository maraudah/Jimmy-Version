var searchData=
[
  ['obj_5fmode',['obj_mode',['../structOamData.html#a1542762eaa267ffb062ffb75d77f3139',1,'OamData']]],
  ['objects',['objects',['../graphics_2sprites_8h.html#a10156b0b336d7423c4b9c2ed2edc7d82',1,'sprites.h']]],
  ['oe_5fstate',['oe_state',['../effects_8h.html#a2f9ff286517e74341ad4f0867be0e95b',1,'effects.h']]],
  ['otid',['otid',['../structPokemonBase.html#a7908a3cc0f69243ce698b9a889a45d06',1,'PokemonBase']]],
  ['otname',['otname',['../structPokemonBase.html#a694367cd1f8b2c5b60202bb63bc9516f',1,'PokemonBase']]]
];
